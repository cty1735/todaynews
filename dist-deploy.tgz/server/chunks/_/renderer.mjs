import { j as eventHandler } from './nitro.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'consola';
import 'node:process';
import 'jose';
import 'node:path';
import 'better-sqlite3';

// ROLLUP_NO_REPLACE 
 const template = "<!doctype html>\n<html lang=\"zh-CN\">\n\n<head>\n  <meta charset=\"UTF-8\" />\n  <link rel=\"icon\" type=\"image/svg+xml\" href=\"/todaynews/icon.svg\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n  <!-- SEO Meta Tags -->\n  <meta name=\"description\" content=\"TodayNews - 实时新闻聚合阅读器，汇集全球热点新闻，提供清爽的阅读体验\" />\n  <meta name=\"keywords\" content=\"新闻,科技新闻,实时新闻,新闻聚合,TodayNews\" />\n  <meta name=\"author\" content=\"TodayNews\" />\n  <meta name=\"robots\" content=\"index, follow\" />\n\n  <!-- Open Graph Meta Tags -->\n  <meta property=\"og:title\" content=\"TodayNews - 实时新闻聚合阅读器\" />\n  <meta property=\"og:description\" content=\"实时新闻聚合阅读器，汇集全球热点新闻，提供清爽的阅读体验\" />\n  <meta property=\"og:type\" content=\"website\" />\n\n  <!-- Twitter Card Meta Tags -->\n  <meta name=\"twitter:card\" content=\"summary_large_image\" />\n  <meta name=\"twitter:title\" content=\"TodayNews - 实时新闻聚合阅读器\" />\n  <meta name=\"twitter:description\" content=\"实时新闻聚合阅读器，汇集全球热点新闻，提供清爽的阅读体验\" />\n\n  <meta name=\"theme-color\" content=\"#F2F6ED\" />\n  <link rel=\"preload\" href=\"/todaynews/Baloo2-Bold.subset.ttf\" as=\"font\" type=\"font/ttf\" crossorigin>\n  <link rel=\"apple-touch-icon\" href=\"/todaynews/apple-touch-icon.png\" sizes=\"180x180\" />\n\n  <script>\n    const query = new URLSearchParams(window.location.search)\n    if (query.has(\"login\") && query.has(\"user\") && query.has(\"jwt\")) {\n      localStorage.setItem(\"user\", query.get(\"user\"))\n      localStorage.setItem(\"jwt\", JSON.stringify(query.get(\"jwt\")))\n      window.history.replaceState({}, document.title, window.location.pathname)\n    }\n  </script>\n  <title>TodayNews</title>\n\n  <!-- 百度统计：只在线上域名加载，本地 localhost/内网地址不打点 -->\n  <script>\n    // 只排除本机/局域网 IP，线上域名才打点\n    if (!/^(localhost|[\\d.]+|\\[.*\\])$/.test(location.hostname)) {\n      var _hmt = _hmt || [];\n      (function () {\n        var hm = document.createElement(\"script\");\n        hm.async = true;\n        hm.src = \"https://hm.baidu.com/hm.js?77d732cc1551fabceed9b6398fa417ef\";\n        document.head.appendChild(hm);\n      })();\n    }\n  </script>\n  <script type=\"module\" crossorigin src=\"/todaynews/assets/index-BIcY61Ek.js\"></script>\n  <link rel=\"stylesheet\" crossorigin href=\"/todaynews/assets/index-Dm05-kfa.css\">\n<link rel=\"manifest\" href=\"/todaynews/manifest.webmanifest\"></head>\n\n<body>\n  <div id=\"app\"></div>\n</body>\n\n</html>\n";

const renderer = eventHandler(async () => {
  return template;
});

export { renderer as default };
