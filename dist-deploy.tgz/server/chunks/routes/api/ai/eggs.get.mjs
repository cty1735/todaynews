import { c as defineEventHandler } from '../../../_/nitro.mjs';
import { e as eggGroups, a as eggUpdatedAt } from '../../../_/ai-eggs.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'consola';
import 'node:process';
import 'jose';
import 'node:path';
import 'better-sqlite3';

const eggs_get = defineEventHandler(() => ({ updatedAt: eggUpdatedAt, groups: eggGroups }));

export { eggs_get as default };
