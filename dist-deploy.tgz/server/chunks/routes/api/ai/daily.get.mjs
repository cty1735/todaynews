import { c as defineEventHandler } from '../../../_/nitro.mjs';
import { g as getDailyData } from '../../../_/ai-news.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'consola';
import 'node:process';
import 'jose';
import 'node:path';
import 'better-sqlite3';

const daily_get = defineEventHandler(() => getDailyData());

export { daily_get as default };
