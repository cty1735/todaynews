import { c as defineEventHandler, g as getQuery } from '../../../_/nitro.mjs';
import { m as myFetch } from '../../../_/fetch.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'consola';
import 'node:process';
import 'jose';
import 'node:path';
import 'better-sqlite3';

const UPSTREAM = "https://api.arenaofbias.icu/api/leaderboard";
const CACHE_TTL = 5 * 6e4;
const PASSTHROUGH = ["by", "category", "domain", "task", "harness", "provider"];
const cache = /* @__PURE__ */ new Map();
const leaderboard_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const params = {};
  for (const key of PASSTHROUGH) {
    const value = query[key];
    if (typeof value === "string" && value) params[key] = value;
  }
  const cacheKey = new URLSearchParams(params).toString();
  const hit = cache.get(cacheKey);
  if (hit && Date.now() - hit.at < CACHE_TTL) return hit.data;
  const data = await myFetch(UPSTREAM, { params, timeout: 15e3 });
  if (cache.size > 64) cache.clear();
  cache.set(cacheKey, { at: Date.now(), data });
  return data;
});

export { leaderboard_get as default };
