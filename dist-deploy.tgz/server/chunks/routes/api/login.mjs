import { c as defineEventHandler, e as createError, f as sendRedirect } from '../../_/nitro.mjs';
import process from 'node:process';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'consola';
import 'jose';
import 'node:path';
import 'better-sqlite3';

const login = defineEventHandler(async (event) => {
  if (!process.env.G_CLIENT_ID) {
    throw createError({ statusCode: 506, message: "Server not configured, login disabled" });
  }
  sendRedirect(event, `https://github.com/login/oauth/authorize?client_id=${process.env.G_CLIENT_ID}`);
});

export { login as default };
